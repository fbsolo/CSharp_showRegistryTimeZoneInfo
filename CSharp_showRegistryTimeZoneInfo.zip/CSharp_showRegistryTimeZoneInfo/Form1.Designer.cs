﻿namespace CSharp_showRegistryTimeZoneInfo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_exit = new System.Windows.Forms.Button();
            this.richtxtbox_timezoneinfo = new System.Windows.Forms.RichTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.richtxtbox_timezoneadjustmentinfo = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btn_exit
            // 
            this.btn_exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold);
            this.btn_exit.Location = new System.Drawing.Point(448, 643);
            this.btn_exit.Margin = new System.Windows.Forms.Padding(2);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(86, 31);
            this.btn_exit.TabIndex = 0;
            this.btn_exit.Text = "E&xit";
            this.btn_exit.UseVisualStyleBackColor = true;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // richtxtbox_timezoneinfo
            // 
            this.richtxtbox_timezoneinfo.Location = new System.Drawing.Point(46, 11);
            this.richtxtbox_timezoneinfo.Margin = new System.Windows.Forms.Padding(2);
            this.richtxtbox_timezoneinfo.Name = "richtxtbox_timezoneinfo";
            this.richtxtbox_timezoneinfo.Size = new System.Drawing.Size(891, 201);
            this.richtxtbox_timezoneinfo.TabIndex = 3;
            this.richtxtbox_timezoneinfo.Text = "";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(317, 510);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(349, 100);
            this.label2.TabIndex = 5;
            this.label2.Text = "Select the text to copy, then press\r\n\r\nCtl-C\r\n\r\nto place that text in the Windows" +
    " clipboard";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(396, 457);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(191, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "Time Zone Adjustment Info";
            // 
            // richtxtbox_timezoneadjustmentinfo
            // 
            this.richtxtbox_timezoneadjustmentinfo.Location = new System.Drawing.Point(46, 254);
            this.richtxtbox_timezoneadjustmentinfo.Margin = new System.Windows.Forms.Padding(2);
            this.richtxtbox_timezoneadjustmentinfo.Name = "richtxtbox_timezoneadjustmentinfo";
            this.richtxtbox_timezoneadjustmentinfo.Size = new System.Drawing.Size(891, 201);
            this.richtxtbox_timezoneadjustmentinfo.TabIndex = 7;
            this.richtxtbox_timezoneadjustmentinfo.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 685);
            this.Controls.Add(this.richtxtbox_timezoneadjustmentinfo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.richtxtbox_timezoneinfo);
            this.Controls.Add(this.btn_exit);
            this.Name = "Form1";
            this.Text = "Time Zone Information From The Windows Registry";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_exit;
        private System.Windows.Forms.RichTextBox richtxtbox_timezoneinfo;
        internal System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox richtxtbox_timezoneadjustmentinfo;
    }
}

