﻿using System;
using System.Windows.Forms;

namespace CSharp_showRegistryTimeZoneInfo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            TimeZoneInfo.AdjustmentRule[] adjustments;
            string timeZoneAdjustmentString = "";
            string timeZoneString = "";
            int timeZoneAdjustmentRuleNumber;

            //  In the outer foreach loop, build a
            //
            //      timeZoneString
            //
            //  string of time zone information sourced
            //  from the Windows registry. Each foreach
            //  iteration covers one time zone. Use a
            //
            //      " | "
            //
            //  delimiter between the values, because some
            //  of the returned values have embedded commas.
            //  This means that data for a CSV file would
            //  need more "cleaning". Add a newline at the
            //  end of each finished time zone. The timeZoneString
            //  variable accumulates for all detected time zones.

            foreach (TimeZoneInfo z in TimeZoneInfo.GetSystemTimeZones())
            {
                timeZoneString += z.Id;
                timeZoneString += "|";
                timeZoneString += z.StandardName;
                timeZoneString += "|";
                timeZoneString += z.DisplayName;
                timeZoneString += "|";
                timeZoneString += z.DaylightName;
                timeZoneString += "|";
                timeZoneString += z.SupportsDaylightSavingTime.ToString();
                timeZoneString += "|";
                timeZoneString += z.BaseUtcOffset.TotalSeconds.ToString();
                timeZoneString += Environment.NewLine;

                //  https://docs.microsoft.com/en-us/dotnet/api/system.timezoneinfo.adjustmentrule?view=netframework-4.8

                //  For this specific z (TimeZoneInfo) value,
                //  build an array of adjustments

                adjustments = z.GetAdjustmentRules();

                //  Reset the rule number for the new set of adjustment
                //  rules in the inner foreach loop.

                timeZoneAdjustmentRuleNumber = 1;

                //  In the inner foreach loop, build a
                //
                //      timeZoneAdjustmentString
                //
                //  string of time zone adjustment information
                //  sourced from the Windows registry. Each foreach
                //  iteration covers one time zone adjustment.
                //  Use a
                //
                //      " | "
                //
                //  delimiter between the values, to keep it consistent
                //  with the outer loop. Future adjustments might
                //  have commas. Also, this means that data for a
                //  CSV file would need more "cleaning". Add a newline
                //  at the end of each finished time zone adjustment.
                //  The timeZoneAdjustmentString variable accumulates
                //  for all detected time zones.

                foreach (TimeZoneInfo.AdjustmentRule adjustment in adjustments)
                {
                    //  Variable z.Id has the time zone ID. The outer For Each
                    //  loop sets this value.

                    timeZoneAdjustmentString += z.Id.ToString();
                    timeZoneAdjustmentString += "|";

                    timeZoneAdjustmentString += timeZoneAdjustmentRuleNumber.ToString();

                    //  Increment ruleNumber for each detected adjustment rule.

                    timeZoneAdjustmentRuleNumber += 1;

                    timeZoneAdjustmentString += "|";
                    timeZoneAdjustmentString += adjustment.DateStart.ToString();
                    timeZoneAdjustmentString += "|";
                    timeZoneAdjustmentString += adjustment.DateEnd.ToString();
                    timeZoneAdjustmentString += "|";
                    timeZoneAdjustmentString += adjustment.DaylightTransitionStart.IsFixedDateRule.ToString();
                    timeZoneAdjustmentString += "|";
                    timeZoneAdjustmentString += adjustment.DaylightTransitionStart.Month.ToString();
                    timeZoneAdjustmentString += "|";
                    timeZoneAdjustmentString += adjustment.DaylightTransitionStart.Day.ToString();
                    timeZoneAdjustmentString += "|";
                    timeZoneAdjustmentString += adjustment.DaylightTransitionStart.Week.ToString();
                    timeZoneAdjustmentString += "|";
                    timeZoneAdjustmentString += adjustment.DaylightTransitionStart.DayOfWeek.ToString();
                    timeZoneAdjustmentString += "|";
                    timeZoneAdjustmentString += adjustment.DaylightTransitionStart.TimeOfDay.ToString();
                    timeZoneAdjustmentString += "|";
                    timeZoneAdjustmentString += adjustment.DaylightTransitionEnd.IsFixedDateRule.ToString();
                    timeZoneAdjustmentString += "|";
                    timeZoneAdjustmentString += adjustment.DaylightTransitionEnd.Month.ToString();
                    timeZoneAdjustmentString += "|";
                    timeZoneAdjustmentString += adjustment.DaylightTransitionEnd.Day.ToString();
                    timeZoneAdjustmentString += "|";
                    timeZoneAdjustmentString += adjustment.DaylightTransitionEnd.Week.ToString();
                    timeZoneAdjustmentString += "|";
                    timeZoneAdjustmentString += adjustment.DaylightTransitionEnd.DayOfWeek.ToString();
                    timeZoneAdjustmentString += "|";
                    timeZoneAdjustmentString += adjustment.DaylightTransitionEnd.TimeOfDay.ToString();
                    timeZoneAdjustmentString += "|";
                    timeZoneAdjustmentString += adjustment.DaylightDelta.TotalSeconds.ToString();
                    timeZoneAdjustmentString += Environment.NewLine;
                }
            }

            //  Remove the ending Environment.Newline characters

            timeZoneAdjustmentString = timeZoneAdjustmentString.Substring(0, (timeZoneAdjustmentString.Length - 2));
            timeZoneString = timeZoneString.Substring(0, (timeZoneString.Length - 2));

            this.richtxtbox_timezoneinfo.Text = timeZoneString;
            Clipboard.SetText(richtxtbox_timezoneinfo.Text);

            this.richtxtbox_timezoneadjustmentinfo.Text = timeZoneAdjustmentString;
            Clipboard.SetText(richtxtbox_timezoneadjustmentinfo.Text);
        }
    }
}